const poolMock: { label: 'liquidity' | 'volume' | 'earnings'; value: string }[] = [
  { label: 'liquidity', value: '222.3M' },
  { label: 'volume', value: '22.3M' },
  { label: 'earnings', value: '0.3%' },
];

export { poolMock };
