export const { BASE_URL, DEV, MODE, PROD, VITE_APP_NAME } = import.meta.env;
